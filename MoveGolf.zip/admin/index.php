<?php

include 'components/connect.php';

session_start();

header('location:dashboard.php');

?>
