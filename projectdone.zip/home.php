<?php

include 'components/connect.php';

session_start();

header('location:index.php');

?>
